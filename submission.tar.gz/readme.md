# Sandtris

## Controls
Left, Right arrow keys for movement
Up, Down arrow keys for rotation
Enter to start
Backspace to restart

## Program
Sand-Tetris! Just like Tetris but you clear lines by connecting a row of the same color sand.
