# Sandtris

## Controls
Left, Right arrow keys for movement
Up for rotation
Down for fast drop
Enter to start
Backspace to restart

## Program
Sand-Tetris! Just like Tetris but you clear lines by connecting a row of the same color sand.

## Notes
Might skip frames at higher loads. Should never tear though.

## Disclaimer
This game actively kills braincells. I am not responsible for brainrot.
