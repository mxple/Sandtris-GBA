/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --device=gba --mode=3 title images/title.png 
 * Time-stamp: Sunday 03/31/2024, 17:48:43
 * 
 * Image Information
 * -----------------
 * images/title.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE_H
#define TITLE_H

extern const unsigned short title[38400];
#define TITLE_SIZE 76800
#define TITLE_LENGTH 38400
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif

