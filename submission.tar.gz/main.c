#include "main.h"

#include <stdio.h>
#include <stdlib.h>

#include "game.h"
#include "gba.h"

int main(void) {
    // Manipulate REG_DISPCNT here to set Mode 3. //
    REG_DISPCNT = BG2_ENABLE | MODE3;

    fillScreenDMA(COL_GRAY);
    while (1) {
        // input polling
        key_poll();

        // game logic
        run();

        // draw
        waitForVBlank();
        // clear buffer
        drawBoard();
        drawPiece();
        drawUI();
        // drawChunks();
    }

    return 0;
}
