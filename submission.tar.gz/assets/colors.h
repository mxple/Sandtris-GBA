#ifndef COLORS_H
#define COLORS_H

// indexes
#define TETR_GREEN 0
#define TETR_RED 1
#define TETR_YELLOW 2
#define TETR_BLUE 3

extern const unsigned short TILES[4][64];

#endif
