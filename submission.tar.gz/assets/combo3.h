#ifndef COMBO_3_H
#define COMBO_3_H

#define combo3_bytes 22282

extern const char combo3[];

#endif
