#ifndef COMBO_2_H
#define COMBO_2_H

#define combo2_bytes 22282

extern const char combo2[];

#endif
