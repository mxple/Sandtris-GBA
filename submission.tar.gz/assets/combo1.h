#ifndef COMBO_1_H
#define COMBO_1_H

#define combo1_bytes 19005

extern const char combo1[];

#endif
