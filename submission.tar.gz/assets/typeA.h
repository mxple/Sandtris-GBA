#ifndef TYPE_A_H
#define TYPE_A_H

#define typeA_bytes 2744719
#define typeA_sampleRate 16384

extern const char typeA[];

#endif
