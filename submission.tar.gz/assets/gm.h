/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --device=gba --mode=3 gm images/gm.png 
 * Time-stamp: Sunday 03/31/2024, 17:48:29
 * 
 * Image Information
 * -----------------
 * images/gm.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GM_H
#define GM_H

extern const unsigned short gm[38400];
#define GM_SIZE 76800
#define GM_LENGTH 38400
#define GM_WIDTH 240
#define GM_HEIGHT 160

#endif

