#ifndef COMBO_4_H
#define COMBO_4_H

#define combo4_bytes 21955

extern const char combo4[];

#endif
