#ifndef DROP_H
#define DROP_H
#define drop_bytes 15729

extern const char drop[];

#endif
