/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --device=gba --mode=3 bg images/bg.png 
 * Time-stamp: Sunday 03/31/2024, 15:55:12
 * 
 * Image Information
 * -----------------
 * images/bg.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BG_H
#define BG_H

extern const unsigned short bg[38400];
#define BG_SIZE 76800
#define BG_LENGTH 38400
#define BG_WIDTH 240
#define BG_HEIGHT 160

#endif

