#include "game.h"
#include "bg.h"
#include "colors.h"
#include "gba.h"
#include "title.h"
#include <stdio.h>

static u16 board[BOARD_HEIGHT + 1][BOARD_WIDTH + 2] = {0};
static int chunks[CHUNKS_HEIGHT][CHUNKS_WIDTH] = {0};

static enum state state = TITLE;
static int score = 0;
static int clearFrame;
static int hasUpdated;

static tetrimino pieceCurr;
static tetrimino pieceNext;

static inline tetrimino newPiece(void) {
    return (tetrimino){
        .x = 24,
        .y = 0,
        .rotation = 0,
        .type = randint(0, 7),
        .color = randint(0, 4),
    };
}

void reset(void) {
    volatile u32 zero = 0;

    // zero board
    DMA[3].src = &zero;
    DMA[3].dst = board;
    DMA[3].cnt = ((BOARD_WIDTH + 2) * (BOARD_HEIGHT + 1) / 2) | DMA_ON |
                 DMA_32 | DMA_SOURCE_FIXED;

    // fill borders
    for (int y = 0; y <= BOARD_HEIGHT; y++) {
        board[y][0] = 0xFFFF;
        board[y][BOARD_WIDTH + 1] = 0xFFFF;
    }
    for (int x = 1; x <= BOARD_WIDTH; x++) {
        board[BOARD_HEIGHT][x] = 0xFFFF;
    }

    // zero chunks
    DMA[3].dst = chunks;
    DMA[3].cnt =
        ((CHUNKS_WIDTH * CHUNKS_HEIGHT)) | DMA_ON | DMA_32 | DMA_SOURCE_FIXED;

    pieceCurr = newPiece();
    pieceNext = newPiece();

    score = 0;
    clearFrame = 12;
    hasUpdated = 1;

    state = START;
}

void drawBoard(void) {
    // TODO: change to use 32
    drawImageDMA32(0, BOARD_X_OFFSET, BOARD_WIDTH + 2, BOARD_HEIGHT,
                   (const unsigned short *)board);
}

void drawChunks(void) {
    for (int y = 0; y < CHUNKS_HEIGHT; y++) {
        for (int x = 0; x < CHUNKS_WIDTH; x++) {
            if (chunks[y][x]) {
                videoBuffer[OFFSET(CHUNK_SIZE * y + 1,
                                   CHUNK_SIZE * x + 2 + BOARD_X_OFFSET,
                                   WIDTH)] = 0xFFF0;
            }
        }
    }
}

void drawPiece(void) {
    for (int i = 0; i < 4; i++) {
        const int *cell = PIECES[pieceCurr.type][pieceCurr.rotation][i];

        drawImageDMA(pieceCurr.y + cell[1],
                     BOARD_X_OFFSET + pieceCurr.x + cell[0], 8, 8,
                     TILES[pieceCurr.color]);
    }
}

void drawUI(void) {
    // next piece
    drawRectDMA32(NEXT_PIECE_OFFSET_Y, NEXT_PIECE_OFFSET_X, 32, 32, 0x1884);
    for (int i = 0; i < 4; i++) {
        const int *cell = PIECES[pieceNext.type][pieceNext.rotation][i];

        drawImageDMA(NEXT_PIECE_OFFSET_Y + cell[1],
                     NEXT_PIECE_OFFSET_X + cell[0], 8, 8,
                     TILES[pieceNext.color]);
    }
}

void drawScore(void) {
    char score_str[10];
    snprintf(score_str, 10, "%d", score);
    drawRectDMA32(SCORE_OFFSET_Y, SCORE_OFFSET_X, 64, 8, 0x1884);
    drawString(SCORE_OFFSET_Y, SCORE_OFFSET_X, score_str, COL_WHITE);
}

static int fillNum;
static int __attribute__((section(".ewram")))
visited[BOARD_HEIGHT][BOARD_WIDTH];

#if 0

struct scanline {
    int x1, x2, y, dy;
};

int fill(int x, int y, int col) {
    static struct scanline stack[BOARD_HEIGHT];
    int sz = 0;

    stack[sz++] = (struct scanline){.x1 = x, .x2 = x, .y = y, .dy = 1};
    stack[sz++] = (struct scanline){.x1 = x, .x2 = x, .y = y - 1, .dy = -1};

    int result = 0;
    while (sz) {
        struct scanline line = stack[--sz];
        int x = line.x1;
        if ((visited[y][x - 1] != fillNum) && (board[y][x] & COL_MASK) == col) {
            while ((visited[y][x - 2] != fillNum) &&
                   (board[y][x - 1] & COL_MASK) == col) {
                visited[y][--x - 1] = fillNum;
                board[y][x] = col;
            }
            if (x < line.x1) {
                stack[sz++] = (struct scanline){.x1 = x,
                                                .x2 = line.x1 - 1,
                                                .y = y - line.dy,
                                                .dy = -line.dy};
            }
        }
        while (line.x1 <= line.x2) {
            while ((visited[y][line.x1 - 1] != fillNum) &&
                   (board[y][line.x1] & COL_MASK) == col) {
                visited[y][line.x1 - 1] = fillNum;
                board[y][line.x1] = col;
                if (line.x1 == BOARD_WIDTH)
                    result = 1;
                ++line.x1;
            }
            if (line.x1 > x) {
                stack[sz++] = (struct scanline){.x1 = x,
                                                .x2 = line.x1 - 1,
                                                .y = y + line.dy,
                                                .dy = line.dy};
            }
            if (line.x1 - 1 > line.x2) {
                stack[sz++] = (struct scanline){.x1 = line.x2 + 1,
                                                .x2 = line.x1 - 1,
                                                .y = y - line.dy,
                                                .dy = -line.dy};
            }
            ++line.x1;
            while (line.x1 < line.x2 &&
                   !((visited[y][line.x1 - 1] != fillNum) &&
                     ((board[y][line.x1] & COL_MASK) == col))) {
                ++line.x1;
            }
            x = line.x1;
        }
    }
    return result;
}

#else

#define INSIDE(X, Y)                                                           \
    ( ((board[Y][X] & COL_MASK) == col) && (visited[Y][X - 1] != fillNum) )

int fill(int x, int y, const int col) {
    // new stack
    static int stack[BOARD_HEIGHT][2];
    int sz = 0;

    int result = 0;

    // add x,y to stack
    stack[sz][0] = x;
    stack[sz][1] = y;
    ++sz;

    // while stack is not empty
    while (sz) {
        // pop into lx, yy
        x = stack[sz - 1][0];
        y = stack[sz - 1][1];
        --sz;
        int lx = x;

        while (INSIDE(lx - 1, y)) {
            visited[y][lx - 2] = fillNum;
            if (lx - 1 == BOARD_WIDTH)
                result = 1;
            --lx;
        }
        while (INSIDE(x, y)) {
            visited[y][x - 1] = fillNum;
            if (x == BOARD_WIDTH)
                result = 1;
            ++x;
        }

        int a = 0, b = 0;
        for (int i = lx; i < x; i++) {
            if (!INSIDE(i, y - 1)) {
                a = 0;
            } else if (!a) {
                stack[sz][0] = i;
                stack[sz][1] = y - 1;
                ++sz;
                a = 1;
            }
            if (!INSIDE(i, y + 1)) {
                b = 0;
            } else if (!b) {
                stack[sz][0] = i;
                stack[sz][1] = y + 1;
                ++sz;
                b = 1;
            }
        }
    }

    return result;
}

#endif

int flood(void) {
    fillNum = 0;

    const volatile u32 zero = 0;
    DMA[3].src = &zero;
    DMA[3].dst = visited;
    DMA[3].cnt =
        (BOARD_HEIGHT * BOARD_WIDTH) | DMA_ON | DMA_SOURCE_FIXED | DMA_32;

    for (int y = 0; y < BOARD_HEIGHT; y++) {
        int col = board[y][1] & COL_MASK;
        if (col == 0)
            continue;
        if (visited[y][0])
            continue;

        ++fillNum;

        if (fill(1, y, col)) {
            return 1;
        }
    }
    return 0;
}

void updateChunk(const int x, const int y) {
    int isActive = 0;
    for (int yy = (y + 1) * CHUNK_SIZE - 1; yy >= y * CHUNK_SIZE; yy--) {
        for (int xx = x * CHUNK_SIZE + 1; xx <= (x + 1) * CHUNK_SIZE; xx++) {
            if (!board[yy][xx])
                continue;

            // fall
            if (!board[yy + 1][xx]) {
                board[yy + 1][xx] = board[yy][xx];
                board[yy][xx] = 0;
                isActive = 1;
            } else if (!board[yy + 1][xx - 1]) {
                board[yy + 1][xx - 1] = board[yy][xx];
                board[yy][xx] = 0;
                isActive = 1;
            } else if (!board[yy + 1][xx + 1]) {
                board[yy + 1][xx + 1] = board[yy][xx];
                board[yy][xx] = 0;
                isActive = 1;
            }
        }
    }

    if (isActive) {
        // activate 2x3 chunks around
        for (int cy = y; cy <= y + 1; cy++) {
            for (int cx = x - 1; cx <= x + 1; cx++) {
                if (cy >= 0 && cy < CHUNKS_HEIGHT && cx >= 0 &&
                    cx < CHUNKS_WIDTH) {
                    chunks[cy][cx] = 1;
                }
            }
        }
    }
    chunks[y][x] = isActive;
}

void updateWorld(void) {
    for (int y = CHUNKS_HEIGHT - 1; y >= 0; y--) {
        for (int x = 0; x < CHUNKS_WIDTH; x++) {
            if (chunks[y][x])
                updateChunk(x, y);
        }
    }
}

int updatePiece(void) {
    int type = pieceCurr.type;
    if (type > 1)
        type = 2;

    // rotate the current piece if necessary
    if (key_hit(BUTTON_DOWN)) {
        pieceCurr.rotation = (pieceCurr.rotation + 1) % 4;
    } else if (key_hit(BUTTON_UP)) {
        pieceCurr.rotation = (pieceCurr.rotation + 4 - 1) % 4;
    }

    // move the current piece left or right if necessary
    if (key_is_down(BUTTON_LEFT)) {
        --pieceCurr.x;
    } else if (key_is_down(BUTTON_RIGHT)) {
        ++pieceCurr.x;
    }

    // check for wall collision
    if (pieceCurr.x < LR_BOUNDS[type][pieceCurr.rotation][0])
        pieceCurr.x = LR_BOUNDS[type][pieceCurr.rotation][0];
    else if (pieceCurr.x > LR_BOUNDS[type][pieceCurr.rotation][1])
        pieceCurr.x = LR_BOUNDS[type][pieceCurr.rotation][1];

    // move the current piece down 1 cell
    ++pieceCurr.y;

    // check for collision with ground or sand
    for (int i = 0; i < 4; i++) {
        const int *cell = PIECES[pieceCurr.type][pieceCurr.rotation][i];
        // check if in bounds
        int x = pieceCurr.x + cell[0];
        int y = pieceCurr.y + cell[1] + 8;
        for (int offset = 0; offset < 8; offset++) {
            // check if hit sand
            if (board[y][x + offset + 1]) {
                return 1;
            }
        }
    }

    return 0;
}

void restart(void) { state = TITLE; }

void run(void) {
    // handle input
    if (key_hit(BUTTON_SELECT)) restart();

    if (key_hit(BUTTON_START))
        state = START;

    switch (state) {
    case TITLE:
        drawFullScreenImageDMA(title);
        if (key_hit(BUTTON_START))
            state = START;
        break;
    case START:
        reset();
        drawFullScreenImageDMA(bg);
        drawUI();
        drawScore();
        state = FALL;
        break;
    case FALL:
        hasUpdated = 1;
        if (updatePiece()) {
            state = SPAWN;
            break;
        }
        updateWorld();
        state = FLOOD;
        break;
    case FLOOD:
        if (updatePiece()) {
            state = SPAWN;
            break;
        }
        if (flood()) {
            state = CLEAR1;
        } else {
            state = FALL;
        }
        break;
    case SPAWN:
        if (!hasUpdated) {
            state = GAMEOVER;
            break;
        }
        hasUpdated = 0;
        // blit current piece to board
        for (int i = 0; i < 4; i++) {
            const int *cell = PIECES[pieceCurr.type][pieceCurr.rotation][i];
            for (int y = 0; y < 8; y++) {
                if (pieceCurr.y + cell[1] + y >= BOARD_HEIGHT)
                    break;
                DMA[3].src = &TILES[pieceCurr.color][8 * y];
                DMA[3].dst = &board[pieceCurr.y + cell[1] + y]
                                   [pieceCurr.x + cell[0] + 1];
                DMA[3].cnt = 8 | DMA_ON;
            }
        }

        // set active chunks
        int ys = (pieceCurr.y / CHUNK_SIZE);
        int xs = (pieceCurr.x / CHUNK_SIZE);
        if (ys < 0)
            ys = 0;
        if (xs < 0)
            xs = 0;
        int ye = ys + 5;
        int xe = xs + 5;
        if (ye >= CHUNKS_HEIGHT)
            ye = CHUNKS_HEIGHT - 1;
        if (xe >= CHUNKS_WIDTH)
            xe = CHUNKS_WIDTH - 1;
        for (int y = ys; y <= ye; y++) {
            for (int x = xs; x <= xe; x++) {
                chunks[y][x] = 1;
            }
        }

        pieceCurr = pieceNext;
        pieceNext = newPiece();
        state = FLOOD;
        break;
    case CLEAR1:
        // color visited white
        for (int y = 0; y < BOARD_HEIGHT; y++) {
            for (int x = 0; x < BOARD_WIDTH; x++) {
                if (visited[y][x] == fillNum) {
                    board[y][x + 1] = 0xFFFF;
                    ++score;
                }
            }
        }
        drawScore();
        state = CLEAR2;
        break;
    case CLEAR2:
        --clearFrame;
        if (clearFrame) {
            state = CLEAR2;
        } else {
            state = CLEAR3;
            clearFrame = 12;
        }
        break;
    case CLEAR3:
        // color visited black
        for (int y = 0; y < BOARD_HEIGHT; y++) {
            for (int x = 0; x < BOARD_WIDTH; x++) {
                if (visited[y][x] == fillNum) {
                    board[y][x + 1] = 0;
                }
            }
        }
        volatile u32 one = 1;
        DMA[3].src = &one;
        DMA[3].dst = chunks;
        DMA[3].cnt = ((CHUNKS_WIDTH * CHUNKS_HEIGHT)) | DMA_ON | DMA_32 |
                     DMA_SOURCE_FIXED;

        state = FALL;
        break;

    case GAMEOVER:
        if (key_hit(BUTTON_START))
            state = START;
        break;
    }
}
